package org.example.pojos;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.*;

import java.io.Serializable;

@XmlRootElement(name = "ProcessAlertTriggerRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ProcessAlertTriggerRequest implements Serializable {
    private String UserID;
    private String PrcsGrpNbr;
    private String Cust;
    private String OrigAppl;
    private String Account;
    private String ProfileID;
    private String ByPassSubscriptCheck;
    private String VarList;
    private String DeliveryMethodList;
}
