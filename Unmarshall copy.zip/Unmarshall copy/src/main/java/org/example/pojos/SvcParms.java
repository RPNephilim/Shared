package org.example.pojos;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.*;

import java.io.Serializable;

@XmlRootElement(name = "SvcParms")
@XmlAccessorType(XmlAccessType.FIELD)
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class SvcParms implements Serializable {
    private String AppID;
    private String SvcID;
    private String SvcVer;
    private String RqstUUID;
    private String RoutindID;

}
