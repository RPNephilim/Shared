package org.example.pojos;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.*;

import java.io.Serializable;

@XmlRootElement(name = "NGProcessAlertTriggerMtvnSvcReq")
@XmlAccessorType(XmlAccessType.FIELD)
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class NGProcessAlertTriggerMtvnSvcReq implements Serializable {
    private String MtvnSvcVer;
    private String MsgUUID;
    private PrcsParms PrcsParms;
    private Svc Svc;
}
