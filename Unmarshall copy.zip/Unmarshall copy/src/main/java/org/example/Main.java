package org.example;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.Marshaller;
import jakarta.xml.bind.Unmarshaller;
import org.example.pojos.NGProcessAlertTriggerMtvnSvcReq;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.util.Scanner;

public class Main {
    private static String trimLine(String data) {
        if (!data.contains("xmlns"))
            return data;
        int i = data.indexOf("xmlns"), j = i;
        while (j < data.length() && data.charAt(j) != '>') {
            j++;
        }
        return data.substring(0, i) + data.substring(j);
    }

    public static void main(String[] args) {

//        System.out.println("Hello world!");

        try {
            File xmlFile = new File("InputXml.xml");
            FileWriter xmlFileWithoutNamespace = new FileWriter("InputWithoutNamespace.xml");
            Scanner reader = new Scanner(xmlFile);
            while (reader.hasNextLine()) {
                String data = reader.nextLine();
                String outputData = trimLine(data);
//                System.out.println(outputData);
                xmlFileWithoutNamespace.write(outputData);
            }
            xmlFileWithoutNamespace.close();
            reader.close();
            File outputFile = new File("InputWithoutNamespace.xml");
            JAXBContext jaxbContext;
            jaxbContext = JAXBContext.newInstance(NGProcessAlertTriggerMtvnSvcReq.class);
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            NGProcessAlertTriggerMtvnSvcReq req = (NGProcessAlertTriggerMtvnSvcReq) jaxbUnmarshaller.unmarshal(outputFile);
            System.out.println(req.getSvc().getMsgData().getProcessAlertTriggerRequest().getPrcsGrpNbr());
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE); // To format XML
            jaxbMarshaller.marshal(req, new FileOutputStream("reply.xml"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}